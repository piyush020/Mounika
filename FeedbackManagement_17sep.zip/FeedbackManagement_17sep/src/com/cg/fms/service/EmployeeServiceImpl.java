package com.cg.fms.service;

import java.util.ArrayList;
import com.cg.fms.dao.EmployeeDao;
import com.cg.fms.dao.EmployeeDaoImpl;
import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao dao;
	
	public EmployeeServiceImpl()
	{
		dao = new EmployeeDaoImpl();
	}

	@Override
	public Employee getEmployeeById(int id) throws FMSException {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(id);
	}

	@Override
	public ArrayList<Employee> getAllEmployees() throws FMSException {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}

	@Override
	public Employee addEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(emp);
	}

	@Override
	public boolean deleteEmployee(int id) throws FMSException {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(id);
	}

	@Override
	public boolean validateId(int id) throws FMSException {
		if(id!=0 && id/10000>1)
			return true;
		else
			return false;
	}

}
